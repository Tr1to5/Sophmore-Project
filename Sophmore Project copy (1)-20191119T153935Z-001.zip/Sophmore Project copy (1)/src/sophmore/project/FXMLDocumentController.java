/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sophmore.project;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author yduong
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextArea textArea;
    @FXML
    private ContextMenu context;
    @FXML
    private MenuItem copy;
    @FXML
    private Button income;
    @FXML
    private Button bill;
    @FXML
    private Button saving;
    @FXML
    private Button download;
    @FXML
    private Button calculate;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void onCopy(ActionEvent event) {
        textArea.copy();
    }

    @FXML
    private void onContext(ActionEvent event) {
    }

    @FXML
    private void onTextArea(MouseEvent event) {

    }

    @FXML
    private void onIncome(ActionEvent event) {
        try {
            Stage stage = (Stage) income.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("Income.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void onBill(ActionEvent event) {
        try {
            Stage stage = (Stage) bill.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("Bill.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void onSaving(ActionEvent event) {
        try {
            Stage stage = (Stage) saving.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("Saving.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void appendText() throws FileNotFoundException {
        BufferedReader file = new BufferedReader(new FileReader("text.txt"));
        Scanner scan = new Scanner(file);
        while (scan.hasNext()) {
            textArea.appendText(scan.nextLine() + "\n");
        }
        scan.close();
    }

    @FXML
    private void onDownload(ActionEvent event) {
        FileChooser chooser = new FileChooser();
        File file = chooser.showSaveDialog(null);
    }

    @FXML
    private void onCalculate(ActionEvent event) throws FileNotFoundException {
        File file = new File("text.txt");
        Scanner scan = new Scanner(file);
        int income = 0;
        int bill = 0;
        int saving = 0;
        int num = 0;
        int left = 0;

        while (scan.hasNext()) {
            String text = scan.nextLine();
            int length = text.length();
            String result = "";
            boolean inSeq = text.contains(" month: $ ");
            boolean outSeq = text.contains(" expenses is $ ");
            boolean savSeq = text.contains(" saving per month ");

            if (inSeq == true) {
                for (int i = 0; i < length; i++) {
                    Character character = text.charAt(i);
                    if (Character.isDigit(character)) {
                        result += character;
                        income = Integer.parseInt(result);
                    }
                }
                left += income;
            }

            if (outSeq == true) {
                for (int i = 0; i < length; i++) {
                    Character character = text.charAt(i);
                    if (Character.isDigit(character)) {
                        result += character;
                        bill = Integer.parseInt(result);
                    }
                }
                left -= bill;
            }

            if (savSeq == true) {
                for (int i = 0; i < length; i++) {
                    Character character = text.charAt(i);
                    if (Character.isDigit(character)) {
                        result += character;
                        saving = Integer.parseInt(result);
                    }
                }

                if (saving > left) {
                    textArea.appendText("The saving goal cannot be satisfy.\n");
                } else {
                    textArea.appendText("The saving goal can be satisfy.\n");
                }
            } 
        }
        textArea.appendText("Leftover per month: $ " + left + ".\n ");
        scan.close();
    }
}
